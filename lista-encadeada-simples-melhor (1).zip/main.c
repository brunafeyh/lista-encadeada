#include <stdio.h>
#include <stdlib.h>

typedef int TipoItem;

typedef struct no{
    TipoItem info;
    struct no *prox;
} Lista;

void liberarLista(Lista *l) {
    while (l != NULL) {
        Lista *temp = l;
        l = l->prox;
        free(temp);
    }
}

int vazia(Lista *l){
    if(l == NULL)
        return 1;
    return 0;
}

Lista* inserir(Lista *l, TipoItem info){
    Lista* aux = (Lista*) malloc(sizeof(Lista));
    aux->info = info;
    aux->prox = l;
    return aux;
}

 Lista* inserirNoFinal(Lista* l, TipoItem info){
    Lista* novo = (Lista*)malloc(sizeof(Lista));
    novo->info = info;
    novo -> prox = NULL;
    
    if(l == NULL){
        return novo;
    }
    else{
        Lista *aux = l;
        while(aux->prox != NULL){
            aux = aux -> prox;
        }
        aux->prox = novo;
    }
    return l;
}

Lista * remover(Lista* l, TipoItem info) {
    Lista * ant = l; // nó anterior
    Lista * p = l; 
    while(p!= NULL && p->info != info) { // localiza o elemento
        ant = p;
        p = p->prox;
    }
    if(p != NULL) { // elemento encontrado
        if(p == l){
            l = l->prox; // atualiza a cabeça
        } // remoção na cabeça
        else{
            ant->prox = p->prox;
        } // remoção no meio
    free(p); // libera o n do elemento removido
    }
    else printf("Elemento não encontrado\n");
    return l;
}

Lista* inverterSemModificar(Lista* l) {
    Lista* reversedList = NULL; // Inicialize a lista invertida como vazia
    Lista* p = l; // Inicialize o ponteiro 'current' na lista original

    while (p != NULL) {
        // Insira o valor do nó atual no início da lista invertida
        reversedList = inserir(reversedList, p->info);
        p = p->prox; // Mova para o próximo nó na lista original
    }
    
    return reversedList; // Retorne a lista invertida
}

Lista* concatenar(Lista* l1, Lista* l2){
    Lista* concatenada = NULL;
    Lista* p = l1;
    
    while (p != NULL) {
        concatenada = inserir(concatenada, p->info);
        p = p->prox; // Mova para o próximo nó na lista original
    }
    p = l2;
    
    while (p != NULL) {
        // Insira o valor do nó atual no início da lista invertida
        concatenada = inserir(concatenada, p->info);
        p = p->prox; // Mova para o próximo nó na lista original
    }
    
    concatenada = inverterSemModificar(concatenada);
    return concatenada;
}

Lista* intercalar(Lista* l1, Lista* l2) {
    Lista* intercalada = NULL;
    
    if (l1 == NULL) {
        return l2; // Se l1 estiver vazia, a lista intercalada é l2
    }
    if (l2 == NULL) {
        return l1; // Se l2 estiver vazia, a lista intercalada é l1
    }

    intercalada = inserirNoFinal(intercalada, l1->info); // Cria a lista intercalada com o primeiro elemento de l1
    intercalada->prox = intercalar(l2, l1->prox); // Intercala o restante das listas, alternando l2 e l1->prox

    return intercalada;
}
void imprimir(Lista* l){
    Lista *p = l;
    while(p != NULL){
        printf("%d ", p->info);
        p = p -> prox;
    }
    printf("\n");
}

int conta_ocorrencias(Lista* l, int x){
    int c = 0;
    if(l!= NULL){
        if(l->info == x){
            c++;
            c+= conta_ocorrencias(l->prox, x);
        }
        else c+= conta_ocorrencias(l->prox, x);
    }
    return c;
}

int numcelulas(Lista *l){
    int c = 0;
    Lista *p;
    for(p = l; p != NULL; p = p->prox){
        c++;
    }
    return c;
}

int main(){
    Lista *l1 = NULL;
    Lista *l2 = NULL;
    Lista *l3 = NULL;
    Lista *concatenada = NULL;
    Lista *intercalada = NULL;
    int n, x;
    
    if(vazia(l1)) printf("Lista vazia\n");
    while(scanf("%d", &n) && n != -1){
        l1 = inserirNoFinal(l1, n);
        printf("Elemento %d inserido com sucesso!\n", n);
    }
    printf("\n");
    
    printf("Lista completa (L1): ");
    
    imprimir(l1);
    
    printf("\n");
    
    printf("Insira o Elemento a ser retirado: ");
    scanf("%d", &x);
    
    l1 = remover(l1, x);
    
    printf("\n");
    
    printf("Lista sem o Elemento (L1): ");
    
    imprimir(l1);
    
    printf("\n");
    
    printf("Lista invertida (l2): ");
    
    l2 = inverterSemModificar(l1);
    
    imprimir(l2);
    
    printf("\n");
    
    printf("Insira os Elementos de l3: ");
    
    while(scanf("%d", &n) && n != -1){
        l3 = inserirNoFinal(l3, n);
        printf("Elemento %d inserido com sucesso!\n", n);
    }
    
    printf("\n");
    printf("Lista l3: ");
    imprimir(l3);
    
    printf("\n");
    
    printf("Lista concatenada (L1 e l3): ");
    concatenada = concatenar(l1, l3);
    imprimir(concatenada);
    
    printf("\n");
    
    printf("Lista intercalada (L1 e l3): ");
    intercalada = intercalar(l1, l3);
    
    imprimir(intercalada);
    
    printf("Essa lista tem %d elementos 3\n", conta_ocorrencias(intercalada, 3));
    printf("Essa lista tem %d celulas\n", numcelulas(intercalada));
    
    liberarLista(l1);
    liberarLista(l2);
    liberarLista(l3);
    liberarLista(concatenada);
    liberarLista(intercalada);
    
    return 0;
}




